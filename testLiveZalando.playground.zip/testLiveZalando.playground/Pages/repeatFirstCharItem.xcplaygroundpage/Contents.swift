
import Foundation

//==========first repeat item
func repeatFirstCharItem(_ str: String) -> String? {
    guard str.count != 0  else {  return nil }
    let tempStr = str.lowercased().filter{$0 != " "}
    let arraySet = NSCountedSet(array: Array(tempStr))
 
    for item in tempStr {
        if  arraySet.count(for: item) > 1 {
            return String(item)
        }
    }
    return nil
}

var fisrRepeatedItem:Any?
func countingFirstRepeatedItem(_ array:[Any]) {
    guard array.count > 0 else {
        return
    }
    let countSet = NSCountedSet(array: Array(array))
    for i in array {
        if   countSet.count(for: i) > 1 {
            fisrRepeatedItem =  i
        }
    }
}
//print(repeatFirstCharItem(str: "qw rt yu uw"))

//================find first repeat item
func repeatFirstCharItem2(str: String)-> String? {
    guard str.count != 0  else {  return nil }
    let tempStr = str.lowercased().filter{$0 != " "}
    let arrayDic = Dictionary(grouping: tempStr, by: {$0}).filter{(key, value) in value.count == 1 }.keys
    return arrayDic.isEmpty ? nil : String(arrayDic.first!)
}

//print(repeatFirstCharItem2(str: "qw rt yu uw"))

//===set
let x = [1, 1, 2, 3, 4, 5, 5]
let duplicates = Array(Set(x.filter({(i: Int) in x.filter({ $0 == i}).count > 1})))
//===========group first char
let students = ["Kofi", "Abena", "Efua", "Kweku", "Akosua","Efua"]
let studentsByLetter = Dictionary(grouping: students, by: { $0.first! })
//let studentsByLetter = Dictionary(grouping: students, by: { _ in students.prefix(2) })

print(studentsByLetter)





let letters = "abracadabra"
      let letterCount = letters.reduce(into: [:]) { counts, letter in
          counts[letter, default: 0] += 1
      }
      // letterCount == ["a": 5, "b": 2, "r": 2, "c": 1, "d": 1]
print(letterCount)
repeatFirstCharItem(letters)


//تکراری ها در دیکشنری
let str = letters.reduce(into: [:]){ count,letter in
    count[letter , default:0] += 1
}
print(str)
//["a": 5, "r": 2, "b": 2, "c": 1, "d": 1]
