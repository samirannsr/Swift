//: [Previous](@previous)

import Foundation
import UIKit

//------------------------- ErorrHandelling
enum errorType: Error {
    case error1
    case error2
}

func order() throws  -> Int{
    
    print (1)
    print (2)
    print(3)
    if 1==1 {
        throw errorType.error1
    } else {  return 1 }
    
}
//--type 1
let x: Int
do {
    x =  try order()
    print(x)
} catch errorType.error1{
    print("error1")
} catch errorType.error2 {
    print("error2")
}

//return error1

//type optional
//try? order() //return nil
//try! order() //error: Execution was interrupted,

/*UIActivity->*/ //  UIActivityViewController(activityItems: <#T##[Any]#>, applicationActivities: <#T##[UIActivity]?#>)

//let g = NSArray()
//g.write(toFile: <#T##String#>, atomically: <#T##Bool#>)

//FileManager.SearchPathDirectory
//let stringArray = NSSearchPathForDirectoriesInDomains(<#T##directory: FileManager.SearchPathDirectory##FileManager.SearchPathDirectory#>, <#T##domainMask: FileManager.SearchPathDomainMask##FileManager.SearchPathDomainMask#>, <#T##expandTilde: Bool##Bool#>).first
//FileManager


print (CharacterSet.uppercaseLetters.contains(UnicodeScalar.chara))
